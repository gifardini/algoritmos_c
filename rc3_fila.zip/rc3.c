#include<stdlib.h>
#include<stdio.h>
#include<assert.h>
#include<string.h>
#include"fila_generica.h"

typedef struct{
    char nome[20];
    int idade;
    int doenca;
} pessoa;


int qtd_espacos(char *str){
    int espacos = 0;
    while(*str){
        if (*str == ' '){
           espacos++;
        }
        str++;
    }
    return espacos;
}


int main(){
    int N;
    scanf("%d", &N);
    
    fila_t *f_p1, *f_p2, *f_p3, *f_p4;
    f_p1 = criar(sizeof(pessoa));
    f_p2 = criar(sizeof(pessoa));
    f_p3 = criar(sizeof(pessoa));
    f_p4 = criar(sizeof(pessoa));

    pessoa p, p_saida;
    char cmd[10] = {0};

    for(int i = 0; i < N; i++){
        scanf("%s", cmd);
        if(!strcmp(cmd, "ENTRA")){
            scanf("%s %d %d", p.nome, &p.idade, &p.doenca);

            if(p.idade >= 60 && p.doenca == 1){
                inserir(f_p1, &p);
            }
            else if(p.idade < 60 && p.doenca == 1){
                inserir(f_p2, &p);
            }
            else if(p.idade >= 60 && p.doenca == 0){
                inserir(f_p3, &p);
            }
            else{
                inserir(f_p4, &p);
            }
            
        }
        else{
            if(!isEmpty(f_p1)){
                remover(f_p1, &p_saida);
                printf("%s %d %d\n", p_saida.nome, p_saida.idade, p_saida.doenca);
            }
            else if(!isEmpty(f_p2)){
                 remover(f_p2, &p_saida);
                 printf("%s %d %d\n", p_saida.nome, p_saida.idade, p_saida.doenca);
            }
            else if(!isEmpty(f_p3)){
                 remover(f_p3, &p_saida);
                 printf("%s %d %d\n", p_saida.nome, p_saida.idade, p_saida.doenca);
            }
            else if(!isEmpty(f_p4)){
                 remover(f_p4, &p_saida);
                 printf("%s %d %d\n", p_saida.nome, p_saida.idade, p_saida.doenca);
            }
            else{
                printf("FILA VAZIA\n");
            }
        }
    }

    destruir(f_p1);
    destruir(f_p2);
    destruir(f_p3);
    destruir(f_p4);
    return 0;
}