#include<stdio.h>
#include<stdlib.h>
#include"lista_j.h"

int main(){
    lista_t *l;

    int T, n, k;
    scanf("%d", &T);

    for(int i = 1; i <= T; i++){
        l = cria();
        scanf("%d %d", &n, &k);

        for(int j = 1; j <= n; j++){
            inserir(l, j);
        }
        printf("Caso %d: %d\n", i, josefo(l, n, k));
        liberar(l);
    }

    return 0;
}